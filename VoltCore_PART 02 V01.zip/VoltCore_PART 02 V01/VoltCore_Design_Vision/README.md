# VoltCore — Full HCI Design Vision

A self-contained, clickable EV charging interface prototype based on the VoltCore Part 1 report.

## Open

Double-click `index.html` in Chrome, Edge or Firefox. No internet connection, packages, developer account or server are required.

## Explore

Start on **Design overview**, a lecturer-friendly board showing the driver journey, screen collection, state language, design principles and prototype status. Click **Launch user journey** or **Dashboard**.

The primary experience: **Sign in → Dashboard → Find a charger → Charger details → Start charging → Live charging → Stop charging → Session summary → History.**

Other screens: **Registration, Wallet & payments, Notifications & feedback, Account**.

- Select a station. Available stations permit starting a simulated session; unavailable stations don't.
- Click **Start charging** to see a confirmation and a demo session.
- Click **Stop charging**, then confirm, to see a session receipt and a new history entry.
- Use search, filters, demonstration wallet top-ups, profile, or the feedback form.
- Charging information, station locations, costs, session data and wallet entries are illustrative. No real payments, hardware, account backend or maps are connected.

## Files

- `index.html`: markup and entrypoint
- `styles.css`: visual system, layouts and responsive rules
- `app.js`: content, navigation and prototype interactions

## Source of the design

This design represents the Part 1 promises for station discovery, status visibility, session controls, charging history, wallet/payment information, feedback, navigation, and HCI/accessibility intentions.
